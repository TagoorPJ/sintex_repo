from __future__ import annotations

import json
import os
from typing import Any, Dict

import httpx
from langchain_core.tools import tool
from dotenv import load_dotenv

from app.utils.logger import get_logger

# ── Load environment variables ────────────────────────────────
load_dotenv()

logger = get_logger(__name__)


# ───────────────────────────────────────────────────────────────
# API CALLER (ENV BASED)
# ───────────────────────────────────────────────────────────────

async def call_evolve_api(payload: Dict[str, Any]) -> Dict[str, Any]:
    BASE_URL = os.getenv("EVOLVE_API_URL")

    headers = {
        "accept": "*/*",
        "program": os.getenv("EVOLVE_PROGRAM", "1"),
        "app": os.getenv("EVOLVE_APP", "PLUMBER"),
        "Content-Type": "application/json"
    }

    api_key = os.getenv("EVOLVE_API_KEY")
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    if not BASE_URL:
        logger.error("[EVOLVE] API URL not configured")
        return {"status": "error", "message": "API URL missing"}

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            url = f"{BASE_URL}/register"
            resp = await client.post(url, json=payload, headers=headers)
            resp.raise_for_status()

            logger.debug(f"[EVOLVE] Success status={resp.status_code}")
            logger.debug(f"[EVOLVE] Response body: {resp.text}")
            return resp.json()

    except httpx.HTTPStatusError as e:
        logger.error(f"[EVOLVE] HTTP error: {str(e)}")
        return {"status": "error", "message": str(e)}

    except Exception as e:
        logger.error(f"[EVOLVE] Unexpected error: {str(e)}")
        return {"status": "error", "message": str(e)}
async def update_member_id_in_wati(mobile_number: str, member_id: str):
    WATI_BASE_URL = os.getenv("WATI_BASE_URL")
    WATI_TOKEN = os.getenv("WATI_TOKEN")

    url = f"{WATI_BASE_URL}/updateContactAttributes/{mobile_number}"

    headers = {
        "accept": "*/*",
        "Authorization": f"Bearer {WATI_TOKEN}",
        "Content-Type": "application/json-patch+json"
    }

    payload = {
        "customParams": [
            {
                "name": "memberID",
                "value": member_id
            }
        ]
    }

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(url, json=payload, headers=headers)

            if resp.status_code == 200:
                logger.debug(f"[WATI] memberID updated for {mobile_number}")
            else:
                logger.error(f"[WATI] Failed: {resp.status_code} | {resp.text}")

    except Exception as e:
        logger.error(f"[WATI] Exception: {str(e)}")
def normalize_mobile_number(mobile: str) -> str:
    mobile = mobile.strip()

    # remove spaces
    mobile = mobile.replace(" ", "")

    # remove + if present
    if mobile.startswith("+"):
        mobile = mobile[1:]

    # remove country code 91 (India)
    if mobile.startswith("91") and len(mobile) > 10:
        mobile = mobile[2:]

    # remove leading 0
    if mobile.startswith("0") and len(mobile) > 10:
        mobile = mobile[1:]

    return mobile
# ───────────────────────────────────────────────────────────────
# TOOL
# ───────────────────────────────────────────────────────────────

@tool("submit_user_registration")
async def submit_user_registration(payload: str) -> str:
    """
    Submits plumber registration data to the backend API and creates a new member profile. On success, it returns a unique User ID.

    Required fields (mandatory):
    - name
    - mobile_number
    - pincode

    The tool must not be called unless all required fields are present.

    Optional fields (include only if provided by the user):
    - number_of_permanent_employees
    - number_of_concurrent_sites
    - annual_water_storage_tank_volume_in_litres
    - major_brands_you_use_in_water_tank
    - annual_pipes_and_fittings_value_in_lakhs
    - major_brands_you_use_in_pipes

    Do not send null, empty, or missing values.

    Callback behavior:
    - If callback = true:
    Call the tool immediately after collecting mandatory fields. Do not wait for optional data.
    - If callback = false:
    You may collect optional business details, but the tool can still be called with only mandatory fields.

    Input format:
    Payload must be a valid JSON string containing:
    - name (string)
    - mobile_number (string)
    - pincode (string or number)
    - callback (boolean, optional)
    - optional fields (if available)

    Response behavior:
    - On success (callback = false):
    Returns JSON: {"status": "success", "user_id": "...", "message": "..."}

    - On success (callback = true):
    Returns JSON: {"status": "success", "user_id": "...", "message": "..."}

    - On pincode not found:
    Returns JSON: {"status": "pincode_error", "message": "pincode_not_found"}
    → When you receive this, tell the user the pincode they entered is not supported
      or not recognized, and ask them to enter a different valid pincode.
      Do NOT end the registration. Wait for the new pincode and call this tool again.

    - On other failure:
    Returns JSON: {"status": "error", "message": "Registration failed. Please try again later."}

    Important rules:
    - Never call the tool without mandatory fields
    - Never assume or fabricate data
    - Always send values in English
    - Always send clean and valid JSON
    - Call immediately once required data is available
    """

    logger.debug("[REGISTRATION TOOL] Start")
    logger.debug(f"[REGISTRATION TOOL] Raw payload: {payload}")

    # ── 1. Parse payload ────────────────────────────────────────
    try:
        data: Dict[str, Any] = json.loads(payload)
    except Exception as e:
        logger.error(f"[REGISTRATION TOOL] Invalid JSON: {str(e)}")
        return "Invalid data format. Please try again."

    logger.debug(f"[REGISTRATION TOOL] Keys received: {list(data.keys())}")

    callback = bool(data.get("callback", False))

    # ── 2. REQUIRED FIELD VALIDATION ────────────────────────────
    required_fields = ["name", "mobile_number", "pincode"]

    missing_fields = [
        f for f in required_fields
        if f not in data or data[f] in [None, ""]
    ]

    if missing_fields:
        return "Please provide name, mobile number, and pincode."

    name = str(data.get("name")).strip()
    raw_mobile = str(data.get("mobile_number"))
    mobile = normalize_mobile_number(raw_mobile)
    pincode = str(data.get("pincode")).strip()

    # ── 3. SCHEMA VALIDATION ────────────────────────────────────

    # Name validation
    if len(name) < 2:
        return "Please enter a valid full name."

    # Mobile validation (10 digit numeric)
    if not (mobile.isdigit() and len(mobile) == 10):
        return "Please enter a valid 10-digit mobile number."

    # Pincode validation (6 digit numeric)
    if not (pincode.isdigit() and len(pincode) == 6):
        return "Please enter a valid 6-digit pincode."

    # ── 4. OPTIONAL FIELD VALIDATION ────────────────────────────
    def validate_number(field_name: str, value: Any):
        try:
            return int(value)
        except:
            raise ValueError(f"Invalid value for {field_name}. Please enter a number.")

    optional_numeric_fields = [
        "number_of_permanent_employees",
        "number_of_concurrent_sites",
        "annual_water_storage_tank_volume_in_litres",
        "annual_pipes_and_fittings_value_in_lakhs",
    ]

    validated_optional_data = {}

    for field in optional_numeric_fields:
        value = data.get(field)
        if value not in [None, ""]:
            try:
                validated_optional_data[field] = validate_number(field, value)
            except ValueError as e:
                return str(e)

    # Free text fields (just clean)
    text_fields = [
        "major_brands_you_use_in_water_tank",
        "major_brands_you_use_in_pipes",
    ]

    for field in text_fields:
        value = data.get(field)
        if value not in [None, ""]:
            validated_optional_data[field] = str(value).strip()

    # ── 5. BUILD API PAYLOAD ────────────────────────────────────
    api_payload = {
        "name": name,
        "mobile_number": mobile,
        "pincode": pincode,
    }

    api_payload.update(validated_optional_data)

    logger.debug(f"[REGISTRATION TOOL] API payload → {api_payload}")

    # ── 6. CALL API ─────────────────────────────────────────────
    api_result = await call_evolve_api(api_payload)

    if api_result.get("status") == "error":
        logger.error(f"[REGISTRATION TOOL] API failed: {api_result}")
        api_message = (api_result.get("message") or "").lower()
        if "pincode" in api_message:
            return json.dumps({
                "status": "pincode_error",
                "message": "pincode_not_found",
            })
        return json.dumps({
            "status": "error",
            "message": "Registration failed. Please try again later.",
        })

    logger.debug("[REGISTRATION TOOL] Success")

    user_id_evolve_generated = api_result.get("member_id")
    # ✅ CALL WATI AFTER REGISTRATION SUCCESS
    if user_id_evolve_generated:
        try:
            # WATI expects country code → so use raw_mobile cleaned
            mobile_for_wati = raw_mobile.replace("+", "").replace(" ", "")

            await update_member_id_in_wati(
                mobile_number=mobile_for_wati,
                member_id=user_id_evolve_generated
            )
        except Exception as e:
            logger.error(f"[WATI] Failed to update memberID: {str(e)}")

    # ── 7. RESPONSE ─────────────────────────────────────────────
    if callback:
        return json.dumps({
            "status": "success",
            "user_id": user_id_evolve_generated,
            "message": (
                f"Registration successful!\n"
                f"Your User ID: {user_id_evolve_generated}\n"
                f"Our team will call you shortly."
            ),
        })

    return json.dumps({
        "status": "success",
        "user_id": user_id_evolve_generated,
        "message": (
            f"Registration successful!\n"
            f"Your User ID: {user_id_evolve_generated}\n"
            f"Our team will contact you shortly."
        ),
    })