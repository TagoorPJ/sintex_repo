import sys
import os
from logging.config import fileConfig

from sqlalchemy import engine_from_config, pool
from alembic import context
from dotenv import load_dotenv

# ─────────────────────────────────────────────────────────────
# ✅ Add project root to path
# ─────────────────────────────────────────────────────────────
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# ─────────────────────────────────────────────────────────────
# ✅ Load env
# ─────────────────────────────────────────────────────────────
load_dotenv()

# ─────────────────────────────────────────────────────────────
# ✅ IMPORT BASE + MODELS (CRITICAL)
# ─────────────────────────────────────────────────────────────
from app.database import Base
import app.models
# ─────────────────────────────────────────────────────────────
# Alembic config
# ─────────────────────────────────────────────────────────────
config = context.config

# ─────────────────────────────────────────────────────────────
# ✅ DB URL (handle async → sync)
# ─────────────────────────────────────────────────────────────
db_url = os.getenv("DATABASE_URL")

if db_url:
    if "asyncpg" in db_url:
        db_url = db_url.replace("asyncpg", "psycopg2")
    elif "asyncmy" in db_url:
        db_url = db_url.replace("asyncmy", "pymysql")

    config.set_main_option("sqlalchemy.url", db_url)

# ─────────────────────────────────────────────────────────────
# Logging
# ─────────────────────────────────────────────────────────────
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# ─────────────────────────────────────────────────────────────
# ✅ Metadata
# ─────────────────────────────────────────────────────────────
target_metadata = Base.metadata

# 🔍 DEBUG (remove later)
print("✅ Tables detected:", list(target_metadata.tables.keys()))

# ─────────────────────────────────────────────────────────────
# OFFLINE
# ─────────────────────────────────────────────────────────────
def run_migrations_offline():
    url = config.get_main_option("sqlalchemy.url")

    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        compare_type=True,
        compare_server_default=True,
    )

    with context.begin_transaction():
        context.run_migrations()


# ─────────────────────────────────────────────────────────────
# ONLINE
# ─────────────────────────────────────────────────────────────
def run_migrations_online():
    connectable = engine_from_config(
        config.get_section(config.config_ini_section),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
            compare_server_default=True,
        )

        with context.begin_transaction():
            context.run_migrations()


# ─────────────────────────────────────────────────────────────
# ENTRY
# ─────────────────────────────────────────────────────────────
if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()